package com.eoi.NutriFit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutriFitApplicationTests {

	@Test
	void contextLoads() {
	}

}
