package com.eoi.NutriFit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutriFitApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutriFitApplication.class, args);
	}

}
